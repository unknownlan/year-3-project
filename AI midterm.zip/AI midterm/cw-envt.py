import pybullet as p
import pybullet_data
import time
import numpy as np
import random
import creature
import genome
import matplotlib.pyplot as plt
import csv

p.connect(p.GUI)
p.setAdditionalSearchPath(pybullet_data.getDataPath())

import math

def make_mountain(num_rocks=100, max_size=0.25, arena_size=10, mountain_height=10):
    def gaussian(x, y, sigma=arena_size/4):
        """Return the height of the mountain at position (x, y) using a Gaussian function."""
        return mountain_height * math.exp(-((x**2 + y**2) / (2 * sigma**2)))

    for _ in range(num_rocks):
        x = random.uniform(-1 * arena_size/2, arena_size/2)
        y = random.uniform(-1 * arena_size/2, arena_size/2)
        z = gaussian(x, y)  # Height determined by the Gaussian function

        # Adjust the size of the rocks based on height. Higher rocks (closer to the peak) will be smaller.
        size_factor = 1 - (z / mountain_height)
        size = random.uniform(0.1, max_size) * size_factor

        orientation = p.getQuaternionFromEuler([random.uniform(0, 3.14), random.uniform(0, 3.14), random.uniform(0, 3.14)])
        rock_shape = p.createCollisionShape(p.GEOM_BOX, halfExtents=[size, size, size])
        rock_visual = p.createVisualShape(p.GEOM_BOX, halfExtents=[size, size, size], rgbaColor=[0.5, 0.5, 0.5, 1])
        rock_body = p.createMultiBody(baseMass=0, baseCollisionShapeIndex=rock_shape, baseVisualShapeIndex=rock_visual, basePosition=[x, y, z], baseOrientation=orientation)

def make_arena(arena_size=10, wall_height=1):
    wall_thickness = 0.5
    floor_collision_shape = p.createCollisionShape(shapeType=p.GEOM_BOX, halfExtents=[arena_size/2, arena_size/2, wall_thickness])
    floor_visual_shape = p.createVisualShape(shapeType=p.GEOM_BOX, halfExtents=[arena_size/2, arena_size/2, wall_thickness], rgbaColor=[1, 1, 0, 1])
    floor_body = p.createMultiBody(baseMass=0, baseCollisionShapeIndex=floor_collision_shape, baseVisualShapeIndex=floor_visual_shape, basePosition=[0, 0, -wall_thickness])

    wall_collision_shape = p.createCollisionShape(shapeType=p.GEOM_BOX, halfExtents=[arena_size/2, wall_thickness/2, wall_height/2])
    wall_visual_shape = p.createVisualShape(shapeType=p.GEOM_BOX, halfExtents=[arena_size/2, wall_thickness/2, wall_height/2], rgbaColor=[0.7, 0.7, 0.7, 1])  # Gray walls

    # Create four walls
    p.createMultiBody(baseMass=0, baseCollisionShapeIndex=wall_collision_shape, baseVisualShapeIndex=wall_visual_shape, basePosition=[0, arena_size/2, wall_height/2])
    p.createMultiBody(baseMass=0, baseCollisionShapeIndex=wall_collision_shape, baseVisualShapeIndex=wall_visual_shape, basePosition=[0, -arena_size/2, wall_height/2])

    wall_collision_shape = p.createCollisionShape(shapeType=p.GEOM_BOX, halfExtents=[wall_thickness/2, arena_size/2, wall_height/2])
    wall_visual_shape = p.createVisualShape(shapeType=p.GEOM_BOX, halfExtents=[wall_thickness/2, arena_size/2, wall_height/2], rgbaColor=[0.7, 0.7, 0.7, 1])  # Gray walls

    p.createMultiBody(baseMass=0, baseCollisionShapeIndex=wall_collision_shape, baseVisualShapeIndex=wall_visual_shape, basePosition=[arena_size/2, 0, wall_height/2])
    p.createMultiBody(baseMass=0, baseCollisionShapeIndex=wall_collision_shape, baseVisualShapeIndex=wall_visual_shape, basePosition=[-arena_size/2, 0, wall_height/2])

def setup():
    p.setGravity(0, 0, -10)

    arena_size = 20
    make_arena(arena_size=arena_size)

    mountain_position = (0, 0, -1)  # Adjust as needed
    mountain_orientation = p.getQuaternionFromEuler((0, 0, 0))
    p.setAdditionalSearchPath('shapes/')
    mountain = p.loadURDF("gaussian_pyramid.urdf", mountain_position, mountain_orientation, useFixedBase=1)

def calculate_fitness(robot_id, start_pos, max_height, peak=(0, 0, 5)):
    # Get the current position of the robot
    pos, _ = p.getBasePositionAndOrientation(robot_id)
    # Calculate the distance from the peak
    distance_from_peak = np.linalg.norm(np.array(peak) - np.array(pos))
    # Calculate the total distance traveled from the start position
    distance_traveled = np.linalg.norm(np.array(pos[:2]) - np.array(start_pos[:2]))
    # Fitness based on inverse of distance from peak, distance traveled, and max height achieved
    fitness = 1 / (distance_from_peak + 1) + distance_traveled + max_height
    return fitness

def simulate_creature(creature, previous_robot_id=None):
    max_attempts = 3
    attempt = 0
    success = False
    robot_id = None

    while attempt < max_attempts and not success:
        try:
            if previous_robot_id is not None:
                try:
                    p.removeBody(previous_robot_id)
                except p.error as e:
                    print(f"Error removing previous robot: {e}")

            urdf_file = f'test_{random.randint(0, 10000)}.urdf'
            with open(urdf_file, 'w') as f:
                f.write(creature.to_xml())
            
            try:
                robot_id = p.loadURDF(urdf_file, (-7, -7, 3))
                if robot_id < 0:
                    raise ValueError(f"Failed to load URDF for creature")
            except p.error as e:
                print(f"Error loading URDF for creature: {e}")
                raise

            try:
                start_pos, _ = p.getBasePositionAndOrientation(robot_id)
                success = True
            except p.error as e:
                print(f"Error getting base position for creature: {e}")
                attempt += 1
                continue

        except Exception as e:
            print(f"Attempt {attempt + 1} failed with error: {e}")
            attempt += 1

    if not success:
        print(f"Failed to initialize creature after {max_attempts} attempts.")
        return None, 0.0

    fitness_list = []
    motors = creature.get_motors()
    sensors = creature.get_sensors()
    num_joints = p.getNumJoints(robot_id)

    # Set the camera
    target_pos = (0, 0, 0)
    distance = 20  # Adjust as needed
    p.resetDebugVisualizerCamera(cameraDistance=distance, cameraYaw=45, cameraPitch=-30, cameraTargetPosition=target_pos)

    max_height = start_pos[2]

    # Run the simulation for this creature for 5 real-time seconds
    simulation_time = 5  # seconds
    timestep = 1.0 / 240.0  # typical physics simulation timestep
    steps = int(simulation_time / timestep)
    
    for t in range(steps):
        sensor_readings = creature.read_sensors()
        for j in range(num_joints):
            if j < len(motors):
                motor_output = motors[j].get_output()
                p.setJointMotorControl2(robot_id, j, p.POSITION_CONTROL, targetPosition=motor_output)
        p.stepSimulation()
        
        try:
            pos, _ = p.getBasePositionAndOrientation(robot_id)
        except p.error as e:
            print(f"Error getting position for creature at step {t}: {e}")
            return robot_id, 0.0
        
        max_height = max(max_height, pos[2])
        
        if t % 240 == 0:  # Print fitness every second (assuming 240 steps per second)
            fitness = calculate_fitness(robot_id, start_pos, max_height)
            fitness_list.append(fitness)
        # time.sleep(timestep)
    
    final_fitness = fitness_list[-1] if fitness_list else calculate_fitness(robot_id, start_pos, max_height)
    return robot_id, final_fitness

def roulette_wheel_selection(creatures, fitness_values, num_selections):
    total_fitness = sum(fitness_values)
    selection_probs = [f / total_fitness for f in fitness_values]
    selected_indices = np.random.choice(len(creatures), num_selections, p=selection_probs)
    return [creatures[i] for i in selected_indices]

# Function to run the experiment with a given population size and number of generations
def run_experiment(population_size, gene_count, motor_count, generations, mutation_rate=0.01):
    setup()
  
    # Generate initial population
    population = [creature.Creature(gene_count=gene_count, motor_count=motor_count) for _ in range(population_size)]
    highest_fitness_per_generation = []

    for generation in range(generations):
        if generation != 0:
            setup()

        print(f"Generation {generation} for population size {population_size}, gene count {gene_count}, and motor count {motor_count}")
        fitness_values = []
        previous_robot_id = None

        for i, cr in enumerate(population):
            previous_robot_id, fitness = simulate_creature(cr, previous_robot_id)
            fitness_values.append(fitness)
        
        highest_fitness = max(fitness_values)
        highest_fitness_per_generation.append(highest_fitness)
        print(f"  Highest fitness in generation {generation}: {highest_fitness}")

        if generation < generations - 1:
            # Selection
            selected_creatures = roulette_wheel_selection(population, fitness_values, population_size // 2)
            # Crossover and mutation
            new_population = []
            for _ in range(population_size):
                parent1, parent2 = random.sample(selected_creatures, 2)
                child_dna = parent1.crossover(parent2)
                mutated_dna = [genome.Genome.mutate_gene(gene) for gene in child_dna]
                new_population.append(creature.Creature(gene_count=gene_count, motor_count=motor_count, dna=mutated_dna))
            population = new_population
        
        # Remove all existing robots from the simulation before the next generation
        body_ids = [p.getBodyUniqueId(bodyIndex) for bodyIndex in range(p.getNumBodies())]
        for body_id in body_ids:
            p.removeBody(body_id)

    return highest_fitness_per_generation

# Define different experiments to test
experiments = [
    {'population_size': 50, 'gene_count': 5, 'motor_count': 3, 'generations': 5},
]

# Run experiments and collect results
all_results = {}
for exp in experiments:
    population_size = exp['population_size']
    gene_count = exp['gene_count']
    motor_count = exp['motor_count']
    generations = exp['generations']
    
    highest_fitness_per_generation = run_experiment(population_size, gene_count, motor_count, generations)
    all_results[gene_count] = highest_fitness_per_generation

    # Save results to CSV file
    with open(f'highest_fitness_results_gene_count_{gene_count}.csv', 'w', newline='') as csvfile:
        fitness_writer = csv.writer(csvfile)
        fitness_writer.writerow(['Generation', 'Highest Fitness'])
        for gen, fitness in enumerate(highest_fitness_per_generation):
            fitness_writer.writerow([gen, fitness])

# Print fitness results for each experiment
for gene_count, fitness_values in all_results.items():
    print(f"Gene Count {gene_count}:")
    for gen, fitness in enumerate(fitness_values):
        print(f"  Generation {gen}: {fitness}")

# Plot the highest fitness values over generations for each experiment
plt.figure()
for gene_count, fitness_values in all_results.items():
    plt.plot(range(len(fitness_values)), fitness_values, label=f'Gene Count {gene_count}')

plt.xlabel('Generation')
plt.ylabel('Highest Fitness')
plt.title('Highest Fitness Over Generations for Different Gene Counts (Population Size 40)')
plt.legend()
plt.show()
